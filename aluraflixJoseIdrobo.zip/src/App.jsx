// App.jsx
import React, { useState, useEffect } from 'react';
import { X, Edit, Trash2, Plus, Home, Play } from 'lucide-react';
import bannerImage from './assets/images/banner.png';

// Configuración del tema
const THEME = {
  background: {
    primary: 'bg-[#0A0C10]',    // Negro azulado (fondo principal)
    secondary: 'bg-[#161B22]',   // Gris muy oscuro (header, footer)
    tertiary: 'bg-[#21262D]',    // Gris oscuro (cards)
    input: 'bg-[#2D333B]',       // Gris más claro (inputs)
    overlay: 'bg-black/50'       // Overlay para modales
  },
  text: {
    primary: 'text-white',
    secondary: 'text-gray-300',
    accent: 'text-violet-400'
  },
  border: 'border-[#444C56]'
};

const categoriasIniciales = [
  { id: 1, nombre: 'Front End', color: 'bg-violet-600' },
  { id: 2, nombre: 'Back End', color: 'bg-cyan-600' },
  { id: 3, nombre: 'Innovación y Gestión', color: 'bg-rose-600' }
];

const videosIniciales = [
  {
    id: 1,
    titulo: '¿Qué significa pensar como programador?',
    categoria: 'Front End',
    imagen: 'https://4kwallpapers.com/images/wallpapers/new-year-firework',
    video: 'https://youtube.com/watch?v=video1',
    descripcion: 'Aprende a pensar como programador'
  }
];

// Componente Modal
const Modal = ({ children, onClose, title }) => (
  <div className={`fixed inset-0 ${THEME.background.overlay} flex items-center justify-center z-50`}>
    <div className={`${THEME.background.secondary} rounded-lg w-full max-w-xl m-4`}>
      <div className="p-4 border-b border-[#444C56]">
        <div className="flex justify-between items-center">
          <h2 className={`text-xl font-bold ${THEME.text.primary}`}>{title}</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-[#2D333B] rounded-full transition-colors"
          >
            <X className={`w-5 h-5 ${THEME.text.primary}`} />
          </button>
        </div>
      </div>
      <div className="p-4">
        {children}
      </div>
    </div>
  </div>
);

// Componente VideoPlayer
const VideoPlayer = ({ videoUrl, onClose }) => {
  const getYouTubeId = (url) => {
    const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/;
    const match = url.match(regExp);
    return (match && match[2].length === 11) ? match[2] : null;
  };

  const videoId = getYouTubeId(videoUrl);
  const embedUrl = `https://www.youtube.com/embed/${videoId}`;

  return (
    <Modal onClose={onClose} title="Reproduciendo">
      <div className="relative pt-[56.25%]">
        <iframe
          className="absolute inset-0 w-full h-full"
          src={embedUrl}
          frameBorder="0"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowFullScreen
        />
      </div>
    </Modal>
  );
};

const App = () => {
  const [videos, setVideos] = useState(() => {
    const savedVideos = localStorage.getItem('videos');
    return savedVideos ? JSON.parse(savedVideos) : videosIniciales;
  });
  const [categorias] = useState(categoriasIniciales);
  const [showVideoModal, setShowVideoModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [currentVideo, setCurrentVideo] = useState(null);
  const [showPlayer, setShowPlayer] = useState(false);
  const [selectedVideo, setSelectedVideo] = useState(null);

  useEffect(() => {
    localStorage.setItem('videos', JSON.stringify(videos));
  }, [videos]);

  // Componente Formulario Video
  const FormularioVideo = ({ onGuardar, videoInicial = {} }) => {
    const [formData, setFormData] = useState(videoInicial);
    const [errores, setErrores] = useState({});

    const validarFormulario = () => {
      const nuevosErrores = {};
      if (!formData.titulo?.trim()) nuevosErrores.titulo = 'El título es requerido';
      if (!formData.categoria) nuevosErrores.categoria = 'La categoría es requerida';
      if (!formData.video?.trim()) nuevosErrores.video = 'El enlace del video es requerido';
      return nuevosErrores;
    };

    const handleSubmit = (e) => {
      e.preventDefault();
      const nuevosErrores = validarFormulario();
      
      if (Object.keys(nuevosErrores).length === 0) {
        onGuardar(formData);
        setFormData({});
        setErrores({});
      } else {
        setErrores(nuevosErrores);
      }
    };

    const limpiarFormulario = () => {
      setFormData({});
      setErrores({});
    };

    return (
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className={`block ${THEME.text.primary} mb-1`}>Título</label>
          <input
            type="text"
            className={`w-full p-2 rounded ${THEME.background.input} ${THEME.text.primary} border 
              ${errores.titulo ? 'border-red-500' : THEME.border}`}
            value={formData.titulo || ''}
            onChange={(e) => setFormData({...formData, titulo: e.target.value})}
            placeholder="Título del video"
          />
          {errores.titulo && <p className="text-red-500 text-sm mt-1">{errores.titulo}</p>}
        </div>

        <div>
          <label className={`block ${THEME.text.primary} mb-1`}>Categoría</label>
          <select
            className={`w-full p-2 rounded ${THEME.background.input} ${THEME.text.primary} border 
              ${errores.categoria ? 'border-red-500' : THEME.border}`}
            value={formData.categoria || ''}
            onChange={(e) => setFormData({...formData, categoria: e.target.value})}
          >
            <option value="">Selecciona una categoría</option>
            {categorias.map(cat => (
              <option key={cat.id} value={cat.nombre}>{cat.nombre}</option>
            ))}
          </select>
          {errores.categoria && <p className="text-red-500 text-sm mt-1">{errores.categoria}</p>}
        </div>

        <div>
          <label className={`block ${THEME.text.primary} mb-1`}>URL de la imagen</label>
          <input
            type="text"
            className={`w-full p-2 rounded ${THEME.background.input} ${THEME.text.primary} border ${THEME.border}`}
            value={formData.imagen || ''}
            onChange={(e) => setFormData({...formData, imagen: e.target.value})}
            placeholder="URL de la imagen de portada"
          />
        </div>

        <div>
          <label className={`block ${THEME.text.primary} mb-1`}>URL del video</label>
          <input
            type="text"
            className={`w-full p-2 rounded ${THEME.background.input} ${THEME.text.primary} border 
              ${errores.video ? 'border-red-500' : THEME.border}`}
            value={formData.video || ''}
            onChange={(e) => setFormData({...formData, video: e.target.value})}
            placeholder="URL del video de YouTube"
          />
          {errores.video && <p className="text-red-500 text-sm mt-1">{errores.video}</p>}
        </div>

        <div>
          <label className={`block ${THEME.text.primary} mb-1`}>Descripción</label>
          <textarea
            className={`w-full p-2 rounded ${THEME.background.input} ${THEME.text.primary} border ${THEME.border}`}
            value={formData.descripcion || ''}
            onChange={(e) => setFormData({...formData, descripcion: e.target.value})}
            placeholder="Descripción del video"
            rows="3"
          />
        </div>

        <div className="flex space-x-4">
          <button
            type="submit"
            className="bg-violet-600 hover:bg-violet-700 text-white px-4 py-2 rounded transition-colors"
          >
            Guardar
          </button>
          <button
            type="button"
            onClick={limpiarFormulario}
            className={`${THEME.background.tertiary} hover:bg-[#2D333B] text-white px-4 py-2 rounded transition-colors`}
          >
            Limpiar
          </button>
        </div>
      </form>
    );
  };

  // Componente VideoCard
  const VideoCard = ({ video }) => (
    <div className={`relative ${THEME.background.tertiary} rounded-lg overflow-hidden group`}>
      <div className="relative">
        <img
          src={video.imagen || '/api/placeholder/320/180'}
          alt={video.titulo}
          className="w-full h-48 object-cover"
        />
        <button
          onClick={() => handlePlayVideo(video)}
          className={`absolute inset-0 flex items-center justify-center ${THEME.background.overlay} 
            opacity-0 group-hover:opacity-100 transition-opacity`}
        >
          <Play className={`w-12 h-12 ${THEME.text.primary}`} />
        </button>
      </div>
      <div className="p-4">
        <h3 className={`text-lg font-bold ${THEME.text.primary}`}>{video.titulo}</h3>
        <p className={THEME.text.secondary}>{video.descripcion}</p>
      </div>
      <div className="absolute bottom-2 right-2 flex space-x-2 opacity-0 group-hover:opacity-100 transition-opacity">
        <button
          onClick={() => handleEditVideo(video)}
          className="p-2 bg-violet-600 hover:bg-violet-700 rounded-full transition-colors"
        >
          <Edit className="w-4 h-4 text-white" />
        </button>
        <button
          onClick={() => handleDeleteVideo(video.id)}
          className="p-2 bg-rose-600 hover:bg-rose-700 rounded-full transition-colors"
        >
          <Trash2 className="w-4 h-4 text-white" />
        </button>
      </div>
    </div>
  );

  // Manejadores de eventos
  const handleSaveVideo = (videoData) => {
    if (videoData.id) {
      setVideos(videos.map(v => v.id === videoData.id ? videoData : v));
      setShowEditModal(false);
    } else {
      const nuevoVideo = {
        ...videoData,
        id: Date.now(),
        createdAt: new Date().toISOString()
      };
      setVideos([...videos, nuevoVideo]);
      setShowVideoModal(false);
    }
  };

  const handlePlayVideo = (video) => {
    setSelectedVideo(video);
    setShowPlayer(true);
  };

  const handleEditVideo = (video) => {
    setCurrentVideo(video);
    setShowEditModal(true);
  };

  const handleDeleteVideo = (id) => {
    if (window.confirm('¿Estás seguro de que deseas eliminar este video?')) {
      setVideos(videos.filter(v => v.id !== id));
    }
  };

  return (
    <div className={`min-h-screen ${THEME.background.primary}`}>
      {/* Header */}
      <header className={`${THEME.background.secondary} p-4 sticky top-0 z-40`}>
        <div className="container mx-auto flex justify-between items-center">
          <h1 className="text-2xl font-bold text-violet-500">AluraFlix Jose Idrobo Daza</h1>
          <div className="flex space-x-4">
            <button
              onClick={() => setShowVideoModal(true)}
              className="bg-violet-600 hover:bg-violet-700 p-2 rounded flex items-center transition-colors"
            >
              <Plus className={`w-6 h-6 ${THEME.text.primary}`} />
              <span className={`ml-2 ${THEME.text.primary}`}>Nuevo Video</span>
            </button>
          </div>
        </div>
      </header>

      {/* Contenido Principal */}
      <main className="container mx-auto p-4">
        {/* Banner */}
          <div className="mb-8 relative h-96 bg-gray-800 rounded-lg overflow-hidden">
            <img
              src={bannerImage}
              alt="Banner Challenge React"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-gray-900 to-transparent" />
            <div className="absolute bottom-8 left-8">
              <h2 className="text-4xl font-bold text-white mb-2">
                Challenge React Alura G7
              </h2>
              <p className="text-gray-300">
                Mis Videos Favoritos de Desarrollo
              </p>
            </div>
          </div>

        {/* Lista de Videos por Categoría */}
        {categorias.map(categoria => {
          const videosCategoria = videos.filter(video => 
            video.categoria === categoria.nombre
          );

          if (videosCategoria.length === 0) return null;

          return (
            <section key={categoria.id} className="mb-8">
              <h2 className={`text-2xl font-bold mb-4 ${THEME.text.primary} ${categoria.color} 
                inline-block px-4 py-2 rounded`}>
                {categoria.nombre}
                </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {videosCategoria.map(video => (
                  <VideoCard key={video.id} video={video} />
                ))}
              </div>
            </section>
          );
        })}
      </main>

      {/* Modal Nuevo Video */}
      {showVideoModal && (
        <Modal 
          title="Nuevo Video" 
          onClose={() => setShowVideoModal(false)}
        >
          <FormularioVideo onGuardar={handleSaveVideo} />
        </Modal>
      )}

      {/* Modal Editar Video */}
      {showEditModal && (
        <Modal 
          title="Editar Video" 
          onClose={() => setShowEditModal(false)}
        >
          <FormularioVideo 
            onGuardar={handleSaveVideo}
            videoInicial={currentVideo}
          />
        </Modal>
      )}

      {/* Modal Reproductor de Video */}
      {showPlayer && selectedVideo && (
        <VideoPlayer 
          videoUrl={selectedVideo.video} 
          onClose={() => setShowPlayer(false)} 
        />
      )}

      {/* Footer */}
      <footer className={`${THEME.background.secondary} p-4 mt-8`}>
        <div className="container mx-auto text-center">
          <h1 className="text-xl font-bold text-violet-500">AluraFlix</h1>
        </div>
      </footer>
    </div>
  );
};

export default App;