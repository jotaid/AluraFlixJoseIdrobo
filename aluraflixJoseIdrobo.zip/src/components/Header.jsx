import React from 'react';
import { Home, Plus } from 'lucide-react';

const Header = ({ onNuevoVideo, onHome }) => {
  return (
    <header className="bg-gray-800 p-4">
      <div className="container mx-auto flex justify-between items-center">
        <h1 className="text-2xl font-bold text-blue-500">AluraFlix</h1>
        <div className="flex space-x-4">
          <button
            onClick={onHome}
            className="p-2 bg-gray-700 rounded"
          >
            <Home className="w-6 h-6 text-white" />
          </button>
          <button
            onClick={onNuevoVideo}
            className="p-2 bg-blue-500 rounded flex items-center"
          >
            <Plus className="w-6 h-6 text-white" />
            <span className="ml-2 text-white">Nuevo Video</span>
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;