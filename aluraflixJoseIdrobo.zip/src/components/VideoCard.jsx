import React from 'react';
import { Edit, Trash2 } from 'lucide-react';

const VideoCard = ({ video, onEditar, onEliminar }) => {
  return (
    <div className="relative bg-gray-800 rounded-lg overflow-hidden">
      <img
        src={video.imagen}
        alt={video.titulo}
        className="w-full h-48 object-cover"
      />
      <div className="p-4">
        <h3 className="text-lg font-bold text-white">{video.titulo}</h3>
        <p className="text-gray-400">{video.descripcion}</p>
      </div>
      <div className="absolute bottom-2 right-2 flex space-x-2">
        <button
          onClick={() => onEditar(video)}
          className="p-2 bg-blue-500 rounded-full"
        >
          <Edit className="w-4 h-4 text-white" />
        </button>
        <button
          onClick={() => onEliminar(video.id)}
          className="p-2 bg-red-500 rounded-full"
        >
          <Trash2 className="w-4 h-4 text-white" />
        </button>
      </div>
    </div>
  );
};

export default VideoCard;